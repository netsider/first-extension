// http://stackoverflow.com/questions/11688171/after-calling-chrome-tabs-query-the-results-are-not-available
var fourmTabs = [];
var GlobalTabs = [];
window.addEventListener("load", windowLoaded, false);

function windowLoaded() {

    var R = document.documentElement.outerHTML; // Get HTML of .html file
	var TAB = document.all[0].innerText; // Get ?
	HTML = document.body.outerHTML; // Get Full HTML
	TEXT = document.body.innerHTML; // Get Text
	
	chrome.tabs.query({}, function (tabs) { // (Asyncronous) function to get current tabs
    for (var i = 0; i < tabs.length; i++) {
        fourmTabs[i] = tabs[i];
		GlobalTabs.push(fourmTabs[i].url);
    }
    for (var i = 0; i < fourmTabs.length; i++) {
        if (fourmTabs[i] != null){
           //window.console.log(fourmTabs[i].url); // Log each tab to console
        }
	}
	});
	//document.writeln('<font color="red">' + R + '</font>'); // Put in Extension Window/Pane
	//var targetDiv = document.getElementById('ONE'); // Put in <div> in HTML file
	//targetDiv.appendChild(document.createTextNode(R));
	
	if (GlobalTabs != null){
	//window.console.log(JSON.stringify(fourmTabs));
	//console.log(GlobalTabs[0].toString); // Doesn't work 
	//console.log(toString(GlobalTabs[0])); // Doesn't work
	//console.log(toString(GlobalTabs)); // Doesn't work
	//console.log(GlobalTabs.toString); // Doesn't work.  Returns native code error
	//console.log(GlobalTabs[1]); // Doesn't work
	 console.log(GlobalTabs);
	 for (var i = 0; i < GlobalTabs.length; i++) {
	 if (GlobalTabs[i] != null){
		window.console.log(GlobalTabs[i].url);
	}}
	}
}